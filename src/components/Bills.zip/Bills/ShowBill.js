import React from "react";
import { useSelector } from "react-redux";  
import PrintBill from "./PrintBill";

const ShowBill = (props) => {
  const { togglePopup, billInfo, customerInfo } = props;

  const userInfo = useSelector((state) => {
    return state.storeData.users.data;
  })

  //Product info
  const productInfo = useSelector((state) => {
    return state.storeData.products.data;
  })

  
  return (
    <div className="popUpWrap">
      <div className="modal-dialog">
        <div className="modal-content">
          <div className="modal-header">
            <h5 className="modal-title" id="staticBackdropLabel">
              Bill details
            </h5>
            <button
              type="button"
              className="btn-close"
              data-bs-dismiss="modal"
              aria-label="Close"
              onClick={togglePopup}
            ></button>
          </div>
          <div className="modal-body">
              <PrintBill userInfo={userInfo} productInfo={productInfo}  customerInfo={customerInfo} billInfo={billInfo}/>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ShowBill;
