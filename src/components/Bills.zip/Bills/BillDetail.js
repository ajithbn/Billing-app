import React, {useEffect} from 'react'
import { useSelector, useDispatch } from 'react-redux'
import PrintBill from './PrintBill'
import { getCustomerinfoById } from '../../selectors/getInfoById'
import { asyncgetBillinfoByid } from '../../actions/actions'

const BillDetail = (props) => {
    const id = props.match.params.id
    //alert(id)

    const dispatch = useDispatch()
    useEffect(() => {
        dispatch(asyncgetBillinfoByid(id))
    },[id])

    const userInfo = useSelector((state) => {
        return state.storeData.users.data
    })

    const productInfo = useSelector((state) => {
        return state.storeData.products.data
    })

    const customerInfo = useSelector((state) => {
        return state.storeData.customers.data
    })

    const billData = useSelector((state) => {
        return state.storeData.bills.data.billdetail
    })
    return (<div className='p-3'>
        <PrintBill userInfo={userInfo} productInfo={productInfo}  customerInfo={getCustomerinfoById(billData.customer,customerInfo)} billInfo={billData}/>
        </div>
    )
}

export default BillDetail