import React from 'react'
import BillForm from './BillForm'
import { useDispatch } from 'react-redux'
import { asyncAddBill } from '../../actions/actions'
import { useHistory } from 'react-router-dom'

const AddBill = (props) => {
    const { togglePopup } = props

    const dispatch = useDispatch()
    let history = useHistory()

    const formSubmit = (formData, togglePopup) => {
        dispatch(asyncAddBill(formData, togglePopup, history))
    }
    return <>
        <BillForm togglePopup={togglePopup} formSubmit={formSubmit}/>
    </>
}

export default AddBill